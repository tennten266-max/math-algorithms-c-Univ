#include <stdio.h>

void reverse(char *rev, char *st)???