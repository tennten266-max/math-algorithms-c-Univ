#include <stdio.h>

void bsort(int *a, int n) {
    int i, j, temp, swapped;

    for (i = 0; i < n - 1; i++) {
        swapped = 0; 
        
        for (j = n - 1; j > i; j--) {
            if (a[j - 1] > a[j]) {
                temp = a[j - 1]; 
                a[j - 1] = a[j];
                a[j] = temp;
                swapped = 1;
            } 
        }
        
        if (swapped == 0) {
            break; 
        }
    }
}


void print_array(int *a, int n) {
    printf("{");
    for (int i = 0; i < n; i++) {
        printf("%d", a[i]);
        if (i < n - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}


int main(void) {
    int n;
    
    printf("n:");scanf("%d", &n) != 1 || n <= 0;

    int a[n];
    int i;
    
    printf("配列の要素:\n");
    for (i = 0; i < n; i++) {
        printf("a[%d]: ", i);scanf("%d", &a[i]) != 1;
    }

    printf("\n並び替え前: ");
    print_array(a, n);
    bsort(a, n);

    printf("並び替え後: ");
    print_array(a, n);

    return 0;
}