#include <stdio.h>
#include <math.h>
//(a)
void deposit(int *paccount, int m){
    *paccount += m;
}

//(b)
void interest(int *paccount,int y,int r){
    int rate = r / 100;

    *paccount = *paccount * pow(1 + rate, y);
}


int main(void){
    int account, m;
    printf("銀行口座の金額");scanf("%d",&account);
    printf("いくら預けるか");scanf("%d",&m);

    deposit(&account, m);

    printf("%d\n",account);

    int y,r;
    printf("何年");scanf("%d",&y);
    printf("金利");scanf("%d",&r);
    interest(&account,y,r);

    printf("%d\n",account);
}