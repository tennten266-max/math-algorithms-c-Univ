#include<stdio.h>
int n_to_b(int n, int b[], int i){
    if (i < 0) 
        return 0;
    b[i] = n % 2;
    return n_to_b(n / 2, b, i-1);
}

int main(void){
    int n,S,i;
    S = 32;
    int b[S];

    for(i = 0;i < S; i++)
        b[i] = 0;

    printf("n:");scanf("%d",&n);
    n_to_b(n, b, S - 1);

    int st = 0;//先頭の0なくす
    while (st < S && b[st] == 0)
        st++;

    printf("b:");
    if (st == S)
        printf("0");
    else{
        for (i = st;i < S; i++)
            printf("%d",b[i]);
    }
    printf("\n");
    
    return 0;
}