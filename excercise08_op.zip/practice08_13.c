#include<stdio.h>
int tnpo(int n){
    if(n % 2 == 0)
        return n / 2;
    else
        return 3 * n + 1;  
}

int collatz(int n){
    if (n <= 0) return -1; 
    if (n == 1) return 0;

    return 1 + collatz(tnpo(n));
}

int main(void){
    int n;
    printf("n=");scanf("%d",&n);
    printf("collatz(%d)=%d",n,collatz(n));

    return 0;
}