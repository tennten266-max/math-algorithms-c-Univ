#include <stdio.h>

int is_prime(int n) {
    int i; // ループ用
    if (n <= 1) 
        return 0;
    if (n == 2) 
        return 1;

    for (i = 2; i < n; i++) {
        if (n % i == 0)
            return 0;
    }
    return 1; // どの数でも割り切れなければ素数
}

int next_prime_r(int n) {
    if(is_prime(n + 1)==0)
        return next_prime_r(n + 1);
    else
        return n + 1;
}

int main(void) {
    int x; 
    printf("正の整数xを入力: ");scanf("%d", &x);

    printf("%d より大きな最小の素数は %d です\n", x,next_prime_r(x));
}