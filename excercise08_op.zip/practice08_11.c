#include <stdio.h>

int sod_r(int n,int k){
    if(k==0)
        return 0;
    else if(n % k == 0)
        return k + sod_r(n,k-1);
    else
        return sod_r(n,k-1);

}

int main(void){
    int n,k;
    
    printf("n=");
    scanf("%d", &n);
    printf("k=");
    scanf("%d", &k);
    if(n < 1 || k < 1)
        printf("enter nonegative integer");
    else
        printf("約数の和は%d\n", sod_r(n,k));
    return 0;
}