#include <stdio.h>
#include <math.h>

struct complex {
  double re;  /* 実部 */
  double im;  /* 虚部 */
};

void printC(struct complex a){
    if (a.re == 0 && a.im == 0)
        printf("nothing");
    else if (a.re == 0)                  //(a)
        printf("%+0.2f i\n", a.im);
    else if (a.im == 0)
        printf("%0.2f \n", a.re);
    else
        printf("%0.2f %+0.2f i\n", a.re, a.im);
}

struct complex addC(struct complex a, struct complex b){    //(b)
  struct complex c;
  c.re = a.re + b.re;
  c.im = a.im + b.im;
  return c;
}

struct complex multC(struct complex a, struct complex b){   //(c)
    struct complex c;
    c.re = a.re * b.re - a.im * b.im;
    c.im = a.re * b.im + a.im * b.re;
    return c;
}

struct complex conjC(struct complex a){     //(d)
    struct complex c;
    c.re = a.re ;
    c.im = -1 * a.im ;
    return c;
}

double absC(struct complex a){     //(e)
    double c;
    c = sqrt(a.re * a.re +  a.im * a.im );
    return c;
}

struct complex divC(struct complex a, struct complex b){   //(f)
    struct complex c;
    double a2 = absC(b);a2 *= a2;
    c.re = (a.re * b.re + a.im * b.im) / a2;
    c.im = (a.im * b.re - a.re * b.im) / a2;
    return c;
}


int main(void) {
   struct complex c1, c2, sum;
   scanf("%lf", &c1.re);
   scanf("%lf", &c1.im);
   scanf("%lf", &c2.re);
   scanf("%lf", &c2.im);
   sum = addC(c1, c2);

  printf("c1: "); printC(c1);
  printf("c2: "); printC(c2);
  printf("c1+c2: ");printC(sum);
  printf("multC:");printC(multC(c1,c2));
  printf("c1のcojC:");printC(conjC(c1));
  printf("c1のabsC:");printf("%lf\n",absC(c1));
  printf("divC:");printC(divC(c1,c2));
}
