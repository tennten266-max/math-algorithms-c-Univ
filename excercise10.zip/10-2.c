#include <stdio.h> //cmd /c "a.exe < data.txt"

typedef struct student {
  int code;
  char name[100];
  int math;
  int eng;
} Student;

void read_student(Student *s) {
      scanf("%d", &s->code );
      scanf("%s", s->name);
      scanf("%d", &s->math);
      scanf("%d", &s->eng);
}

Student max_eng(Student a[], int num){  //(a)//引数に使うときは[]のみ
    int i ,j = 0;
    for (i = 0;i < num; i++){
        if (a[j].eng < a[i].eng)
            j = i;
    }
    return a[j];
}

int ave_math(Student a[], int num, int b){  //(b)
    int i,ave = 0,j=-1;
    Student a2[num];//変数宣言にはかっこいる
    for (i = 0;i < num; i++){
        if (b -1 < a[i].eng){
            j += 1;
            a2[j] = a[i];
        }
    }
    for (i = 0;i-1 < j; i++){
        ave += a2[i].math;
    }
    ave = ave / num;
    return ave;
}

int main(void) {
   int num, i;
   /* 人数を指定 */
   scanf("%d", &num);
   /* num個のStudent型構造体を宣言 */
   Student a[num];
   /* num個のStudent型構造体に情報を入力 */
   for (i = 0; i < num; i++) {
      read_student(&a[i]);
   }
   /* num個のStudent型構造体の情報を表示 */
   for (i = 0; i < num; i++) {
      printf("%03d\t", a[i].code);
      printf("%s\t", a[i].name);
      printf("%d\t", a[i].math);
      printf("%d\n", a[i].eng);
   }
   printf("max.name = %s\n",max_eng(a, num).name);//関数に配列使うときはかっこいらない
   int b = 50;
   printf("ave = %d\n",ave_math(a, num, b));
}