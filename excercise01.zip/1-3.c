#include <stdio.h>
int main(void)
//3 kawashima
{
    printf("K  Kk     A     W     W     A     SSSSS H   H I  MMM MMM     A     \n");
    printf("kKK      A A    W     W    A A    S     H   H I  M M M M    A A    \n");
    printf("k       AAAAA   W  W  W   AAAAA   SSSSS HHHHH I  M  M  M   AAAAA   \n");
    printf("kkK    A     A  W W W W  A     A      S H   H I  M     M  A     A  \n");
    printf("k  Kk A       A WWW WWW A       A SSSSS H   H I  M     m A       A \n");
}
