#include <stdio.h>
int main(void)
//1 こんにちは
{
    printf("こ\n");
    printf("ん\n");
    printf("に\n");
    printf("ち\n");
    printf("は\n");
}