#include<stdio.h>

typedef struct rational {
    int num;
    int denom;
} Rational;

int gcd(int a, int b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int lcm(int a, int b){
    if(gcd(a,b)==0)return 0;
    return a * b / gcd(a,b);
}

void reduce(Rational* r){   //(a)
    int c = gcd((*r).num,(*r).denom);
    if(c !=0){
        (*r).num /= c;
        (*r).denom /= c;
    }
}
void mult_rat(Rational r1,Rational r2){  //(b)
    Rational r3;
    r3.num = r1.num * r2.num;
    r3.denom = r1.denom * r2.denom;
    reduce(&r3);
    printf("mult = %d / %d\n",r3.num,r3.denom);
}

void add_rat(Rational r1,Rational r2){   //(c)
    Rational r4;
    r4.denom = r1.denom * r2.denom;
    r4.num = r1.num * r2.denom + r1.denom * r2.num;
    reduce(&r4);
    printf("add = %d / %d\n",r4.num,r4.denom);
}

int main(void){
    Rational r1, r2;
    printf("r1.num, r1.denom=");scanf("%d %d",&r1.num, &r1.denom);
    printf("r2.num, r2.denom=");scanf("%d %d",&r2.num, &r2.denom);

    mult_rat(r1,r2);
    add_rat(r1,r2);
}