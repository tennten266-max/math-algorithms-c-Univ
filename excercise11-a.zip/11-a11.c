#include<stdio.h>
#include<math.h>

#define eps 1e-10

double sqrt_newton(double x){
    double x0 = x, xnext=(x0 + x / x0) / 2.0;
    while(fabs(x0 - xnext) > eps){
        x0 = xnext;
        xnext = (x0 + x / x0) / 2.0;
    }
    return xnext;
}

double cbrt_newton(double x){
    double x0 = x, xnext= (2 * x0 + x / x0 / x0) / 3;
    while(fabs(x0 - xnext) > eps){
        x0 = xnext;
        xnext = (2 * x0 + x / x0 / x0) / 3;

    }
    return xnext;
}

int main(void){
    double x;
    printf("x=");scanf("%lf",&x);
    printf("sqrt=%lf\n",sqrt_newton(x));
    printf("cbrt=%lf\n",cbrt_newton(x));
}