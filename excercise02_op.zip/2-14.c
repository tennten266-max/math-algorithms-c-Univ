#include<stdio.h>
//2-14.c
int main(void)
{
    double r,a,b,c,d,e,pi;
    pi = 3.14;
    printf("円の半径rは");scanf("%lf", &r);

    a = 2 * r;
    b = a * pi;
    c = pi * r*r;
    d = a * r;
    e = 6 * sqrt(3) / 4 * r*r;

    printf("円の直径は%lf\n",a);
    printf("演習の長さは%lf\n",b);
    printf("円の面積は%lf\n",c);
    printf("円に内接する正方形の面積は%lf\n",d);
    printf("円に内接する正6角形の面積は%lf\n",e);
}