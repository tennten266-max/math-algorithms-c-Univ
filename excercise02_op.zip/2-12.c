#include<stdio.h>
//2-12.c
int main(void)
{
    double f,i,L;
    printf("feet:"); scanf("%lf", &f);
    printf("inch:"); scanf("%lf", &i);

    L = (f + 12 * i) / 30.48;

    printf("lengh is %lf cm",L);
}