#include<stdio.h>
//2-11.c
int main(void)
{
    int x,y;
    printf("x:"); scanf("%d", &x);
    printf("y:"); scanf("%d", &y);
    
    printf("交換前:x=%d, y=%d\n", x,y);
    int z;
    z = x;x = y;y = z;
    printf("交換後:x=%d, y=%d\n", x,y);
}