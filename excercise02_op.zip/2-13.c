#include<stdio.h>
//2-13.c
int main(void)
{
    int x;
    double a,b;
    printf("x:"); scanf("%d", &x);

    a = sqrt(3) / 4 * x*x;
    b = sqrt(2) / 12 * x*x*x;

    printf("一辺がxである正三角形の面積は%lf\n",a);
    printf("一辺がxである正四面体の体積は%lf",b);
}