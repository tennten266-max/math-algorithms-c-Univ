#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(void)
{
    srand(time(NULL));
    int x = rand() % 10 + 1;

    if(x >= 7)
    {
        printf("4");
    }
    else
    {
        if(x >= 4)
        {
            printf("3");
        }
        else
        {
            if(x >= 2)
            {
               printf("2"); 
            }
            else
            {
                printf("1");
            }
        }
    }
}