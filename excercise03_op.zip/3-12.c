#include<stdio.h>

int main(void)
{
    int x;
    printf("西暦");scanf("%d",&x);

    if(x >= 1868)
    {
        if(x >= 1912)
        {
            if(x >= 1926)
            {
                if(x >= 1989)
                {
                    if(x >= 2019)
                    {
                        printf("令和%d年です",x - 2019 + 1); 
                    }
                    else
                    {
                        printf("平成%d年です",x - 1989 + 1); 
                    }
                }
                else
                {
                    printf("昭和%d年です",x - 1926 + 1); 
                }
            }
            else
            {
               printf("大正%d年です",x - 1912 + 1); 
            }
        }
        else
        {
            printf("明治%d年です",x - 1868 + 1); 
        }   
    }
    else
    {
        printf("わかりません");
    }
}