#include<stdio.h>

int main(void){
    int x,s;
    printf("文字を入力");
    x = getchar();
    s = x - 97;
    putchar(97 + (s + 3)%26);
}