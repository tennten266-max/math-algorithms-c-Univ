#include<stdio.h>

int main(void){
    int a,b;
    printf("a=");scanf("%d",&a);
    printf("b=");scanf("%d",&b);
    if(a%b == 0)
    {
        printf("bはaの約数です");
    }
    else
    {
        printf("bはaの約数ではありません");   
    }
}