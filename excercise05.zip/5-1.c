#include<stdio.h>
#include<math.h>
#include <stdlib.h>
int main(void)
{
    int a[3][3],i,j,matrix[3][3];
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            printf("integer a[%d][%d]=",i,j);scanf("%d",&a[i][j]);
            //matrix[i][j]=a[i][j];
        }
    }

    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            printf("%3d ",a[i][j]);
        }
        printf("\n");
    }
    int det;
    /*matrix[3][3]=
        {a[0][0], a[0][1], a[0][2]},
        {a[1][0], a[1][1], a[1][2]},
        {a[2][0], a[2][1], a[2][2]},*/
    
    //det = calculate_determinant_sarrus(matrix);
    //行列式の出し方がわからなかったのでどろくさくいく
    det = a[0][0]*a[1][1]*a[2][2] + a[1][0]*a[2][1]*a[0][2] + a[0][1]*a[1][2]*a[2][0]
         -a[0][0]*a[1][2]*a[2][1] - a[0][1]*a[1][0]*a[2][2] - a[0][2]*a[1][1]*a[2][0];//さらすの公式
    printf("%d\n",det);
}