#include<stdio.h>
int main(void)
{
    int a[20],i,j;
    i = 0;
    do{
        printf("a[%d]=",i);scanf("%d",&a[i]);
        i++;
    } while(a[i-1]>=0);
    for(j=i-2;j>=0;j--){
        printf("%d\n",a[j]);
    }
}//20で終わるプログラムは可能だったら後で作る
