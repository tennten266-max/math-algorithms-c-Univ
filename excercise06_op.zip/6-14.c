#include<stdio.h>
#include<math.h>
int main(void)
{
    int a,b,c,D;
    scanf("%d%d%d",&a,&b,&c);
    double dd;

    if(a==0 && b==0){
        if(c==0){
            printf("不定");
        }
        else{
            printf("不能");
        }
    }else if(a==0 && b!=0){
        dd=(double)-c/b;
        printf("x=%f",dd);
    }else{
        D=b*b-4*a*c;
        if(D<0){
            printf("解なし");
        }else{
            double eps,s1,t1,m1,s2,t2,m2,x1,x2;
            eps=0.0000001;
            t1=-b/(2*a);
            s1=-b/a;
            s2=-b/(2*a); 
            t2=0;
            while((t1-s1)>eps){
                m1=(s1+t1)/2;
                x1=a*m1*m1+b*m1+c;
                if(x1<0){
                    t1=m1;
                }else{
                    s1=m1;
                }
            }
            while((t2-s2)>eps){
                m2=(s2+t2)/2;
                x2=a*m2*m2+b*m2+c;
                if(x2>0){
                    t2=m2;
                }else{
                    s2=m2;
                }
            }
            printf("x=%f,%f",m1,m2);
        }
    }
}