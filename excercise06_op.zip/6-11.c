#include<stdio.h>
int main(void)
{
    int max,n=10;
    int i,s,a[n],l,nn=1,k=2;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    
    for(i=n;i>=1;i--){
        nn *=i;//(n)!をnnとした
    }
    for(s=0;s<nn;s++){
        for(i=0;i<=n-2;i++){
            if(a[i+1]<=a[i]){
                l=a[i];
                a[i]=a[i+1];
                a[i+1]=l;//a[i]とa[i+1]の入れ替え
            }
        }
    }
    printf("%d番目に大きい数字は%d\n",k,a[n-k]);//k番目に大きい数
}