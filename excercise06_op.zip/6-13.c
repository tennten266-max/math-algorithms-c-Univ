#include<stdio.h>
int main(void)
{
    double eps,s,t,m;
    eps=0.00001;
    s=0; t=2;
    while((t-s)>eps){
        m=(s+t)/2;
        if(m*m>2){
            t=m;
        }else{
            s=m;
        }
    }
    printf("ルート2は大体%f",s);
}