#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(void)
{
    srand(time(NULL));

    int num[10000],i;
    float ave = 0;
    for(i=0;i<10000;i++)
    {
        num[i] = rand()%10 + 1;
        ave = ave + num[i];
    }
    ave = ave / 10000;
    printf("average=%f",ave);
}