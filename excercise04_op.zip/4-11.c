#include<stdio.h>
#include<math.h>
int main(void)
{
    int i;
    for(i=0;i<=180;i = i + 5)
    {
        printf("sin%d°=%lf, cos%d°=%lf\n",i,sin(i*M_PI/180),i,cos(i*M_PI/180));
    }
}