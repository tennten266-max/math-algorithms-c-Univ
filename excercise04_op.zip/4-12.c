#include<stdio.h>
#include<math.h>
int main(void)
{
    int a[5];
    int i;

    for(i=0;i<5;i++)
    {
        printf("a[%d]=",i);scanf("%d",&a[i]);
    }
    
    float norm;
    norm = 0;
    for(i=0;i<5;i++)
    {
        norm += a[i]*a[i];
    }
    norm = sqrt(norm);
    printf("aのノルムは%f",norm);

}