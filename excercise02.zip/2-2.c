#include<stdio.h>
//2-2.c
int main(void)
{
    int x,h,m,s,ks;
    h=0;
    m=0;
    s=0;
    printf("x=?");scanf("%d",&x);

    h = x / 3600;
    x = x - 3600*h;
    m = x / 60;
    x = x - 60*m; 
    s = x;  
           
    printf("%d時間",h);
    printf("%d分",m);
    printf("%d秒\n",s);
}