#include<stdio.h>
//2-1.c
int main(void)
{
    int h,m,s,sum;
    printf("h=?");scanf("%d",&h);
    printf("m=?");scanf("%d",&m);
    printf("s=?");scanf("%d",&s);
    sum = 60*60*h + 60*m + s;
    printf("合計は%d秒",sum);
    
}