#include<stdio.h>
//2-3.c
int main(void)
{
    int x,a,b;
    printf("x=?");scanf("%d",&x);
    a = x / 10;
    b = x / 100;

    a = x - 10 * a;//aは１の位の一桁の値
    b = 100 * b;//bは10の位より下は0の値

    x = x - b - a;
    x = x / 10;
    printf("%d",x);

    /*mod100して割る10でもいける*/

}