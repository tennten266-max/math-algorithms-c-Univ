#include<stdio.h>
//2-4.c
int main(void)
{
    double x,y,u,v,d;
    printf("(x,y)と(u,v)の距離を求める\n");
    printf("x=?");scanf("%lf",&x);
    printf("y=?");scanf("%lf",&y);
    printf("u=?");scanf("%lf",&u);
    printf("v=?");scanf("%lf",&v);

    d = (x-u)*(x-u) + (y-v)*(y-v);
    d = sqrt(d);

    printf("距離は%lfです",d);
}