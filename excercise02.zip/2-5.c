#include<stdio.h>
//2-5.c
int main(void)
{
    double b,n,x;
    
    printf("b=");scanf("%lf",&b);    
    printf("n=");scanf("%lf",&n);
    x = log(n) / log(b);
    printf("log_b(n)=%lf",x);
}