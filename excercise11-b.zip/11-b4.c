#include<stdio.h>

int main(void){
    int n;
    printf("n=");scanf("%d",&n);
    int a[n + 1][n + 1];

    for(int i = 0;i < n+1; i++){
        for(int j = 0;j < n+1; j++){
            a[i][j] = 0;
        }
    }

    a[0][0]=1;
    for(int i = 1;i < n+1; i++){
        for(int j = 1;j < n+1; j++){
            a[i][j] = a[i-1][j-1] + a[i-1][j];
        }
    }

    for(int i = 1;i < n+1; i++){
        for(int j = 1;j < n+1; j++){
            printf("%d",a[i][j]);
            printf(" ");
        }
        printf("\n");
    }
}