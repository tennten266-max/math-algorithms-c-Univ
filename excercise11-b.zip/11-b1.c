#include<stdio.h>
int funcb1(int n){
    int sum=0, x, y, z;

    for(x=1; x <=n; x++){
        for(y=x; y <=n; y++){
            for(z=y; z <=n; z++){
                if(z*z == x*x + y*y){
                    printf("%d %d %d\n",x, y,z);
                    sum +=1;
                }
            }
        }
    }
    return sum;
}

int main(void){
    int n;
    printf("n=?");scanf("%d",&n);

    printf("合計 %d",funcb1(n));
}