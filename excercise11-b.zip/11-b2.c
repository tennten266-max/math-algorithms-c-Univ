#include<stdio.h>
#include<math.h>
double taylor_e(int x,int n){
    int i;
    double sum = 1, term = 1;
    if(n==0)return sum;
    for(i=1;i<=n;i++){
        term *= (x / (double)i);
        sum += term;
    }
    return sum;
}

int main(void){
    int n;
    printf("n   taylor_e(2.0,n)   error\n");
    for(n = 0; n <21; n++){
        printf("%d",n);
        printf("   ");
        printf("%lf",taylor_e(2,n));
        printf("     ");
        printf("%e\n",fabs(exp(2.0) - taylor_e(2,n)));
    }

    return 0;
}