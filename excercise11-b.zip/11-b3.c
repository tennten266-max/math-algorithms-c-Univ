#include<stdio.h>
#include<math.h>

double taylor_e_r(int x,int n){
    double sum = 0, term = 1;

    if(n==0)return 1.0;

    for(int i = 1; i <=n; i++){
        term *= (double)x / i;
    }

    return term + taylor_e_r(x,n-1);
}

int main(void){
    int n;
    printf("n   taylor_e_r(2.0,n)   error\n");
    for(n = 0; n <21; n++){
        printf("%d",n);
        printf("   ");
        printf("%lf",taylor_e_r(2,n));
        printf("     ");
        printf("%e\n",fabs(exp(2.0) - taylor_e_r(2,n)));
    }

    return 0;
}