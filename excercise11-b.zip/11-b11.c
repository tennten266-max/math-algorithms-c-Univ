#include<stdio.h>

int min_ind(int* a, int n, int i){
    int j = i;
    for(int k = i; k < n; k++){
        if(a[j] > a[k]) 
        j = k;
    }
    return j;
}

void ssort(int* a, int n){
    int s,k;
    for(int i=0; i < n;i++){
        s = a[i];
        k = min_ind(a, n, i);
        a[i] = a[k] ;
        a[k] = s;
    }
}

int main(void){
    int n;
    //printf("n=");scanf("%d",&n);
    n = 10;
    int a[n];
    for(int i = 0; i < n; i++){
        printf("a[%d]=",i);scanf("%d",&a[i]);
    }
    ssort(a, n);
    for(int i=0; i < n; i++){
        printf("%d ",a[i]);
    }
}