#include<stdio.h>
int main(void)
{
    int max,n=10;
    int i,a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    
    max = a[0];
    for(i=0;i<n;i++){
        if(a[i]<a[i+1]){
            max = a[i+1];
        }
    }
    printf("最大値は%d",max);
}