#include<stdio.h>
#include<math.h>
int main(void)
{
    int a,b,c,D;
    scanf("%d%d%d",&a,&b,&c);
    double dd;

    if(a==0 && b==0){
        if(c==0){
            printf("不定");
        }
        else{
            printf("不能");
        }
    }else if(a==0 && b!=0){
        dd=(double)-c/b;
        printf("x=%f",dd);
    }else{
        D=b*b-4*a*c;
        if(D==0){
            dd=(double)-1*b/(2*a);
            printf("x=%f",dd);
        }else if(D>0){
            dd=(double)(-b + sqrt(D))/(2*a);
            printf("x=%f",dd);
            dd=(double)(-b - sqrt(D))/(2*a);
            printf(",%f",dd);
        }
        else if(D<0){
            printf("解なし");
        }
    }
}