#include<stdio.h>
int main(void)
{
    int y;
    scanf("%d",&y);
    switch(y%4){
        case 0:
            if(y%100 !=0 || y%400 == 0)
            printf("うるう年");
            else printf("平年");
            break;
        default:
            printf("平年");
    }
}