#include<stdio.h>
int main(void)
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);

    if(a>b && a>c){
        if(b>c){
            printf("%d",b);
        }//a>b>c
        else if(c>b){
            printf("%d",c);
        }//a>c>b
    }
    if(b>a && b>c){
        if(a>c){
            printf("%d",a);
        }//b>a>c
        else if(c>a){
            printf("%d",c);
        }//b>c>a
    }
    if(c>a && c>b){
        if(a>b){
            printf("%d",a);
        }//c>a>b
        else if(b>a){
            printf("%d",b);
        }//c>b>a
    }
}