#include<stdio.h>
int main(void)
{
    int n,i,k;
    printf("n=");scanf("%d",&n);

    for(i=0;i<n;i++){
        for(k=0;k<i+1;k++){
            printf(" ");
        }
        for(k=n-i-1;k>=0;k--){
            printf("*");
        }
        printf("\n");
    }
}