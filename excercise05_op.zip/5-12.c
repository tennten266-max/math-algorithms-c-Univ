#include<stdio.h>
int main(void)
{
    int i,cnt[10];
    for(i=0;i<10;i++){
        cnt[i]=0;
    }
    int x;
    for(i=0;i<20;i++){
        printf("%d番目の数は",i);scanf("%d",&x);
        cnt[x]+=1;
    }
    for(i=0;i<10;i++){
        printf("cnt[%d]=%d\n",i,cnt[i]);
    }
}