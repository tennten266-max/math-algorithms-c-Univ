#include<stdio.h>
#include<ctype.h>
#include<string.h>
int main(void){
    char st[100];
    printf("文字を入力してください\n");
    scanf("%s",&st);

    printf("シーザー暗号は\n");

    int i,len,x;
    len = strlen(st);
    for(i=0;i<len;i++){
        x = st[i];//勝手にASC11コードになる
        putchar(97 + (x - 97 + 3)%26);
    }
}