#include<stdio.h>
#include<math.h>
int main(void)
{
	int n,i,j;
    printf("n=");scanf("%d",&n);
    int p[n+1];
    for(i=0;i<n+1;i++){
        p[i]=1;
    }
    /*int s;
    for(i=2;i<=sqrt(n);i++){
        if(p[i]==1){
            for(j=2;j<=n;j++){
                s=(i*j);
                s=s%(n+1);
                p[s]=0;
            }
        }
    }
    p[0]=1;p[1]=1;*/
    for (i = 2; i <= sqrt(n); i++) {
        if (p[i] == 1) {
            for (j = i * i; j <= n; j += i) {
                p[j] = 0;
            }
        }
    }

    for(i=0;i<=n;i++){
        if(p[i]==1){
            printf("%d,",i);
        }
    }
}