#include <stdio.h>

int max_of_r(int a[], int i){
    if(i == 0){
        return a[0];
    }
    else{
        if(a[i] >= max_of_r(a, i-1)){
            return a[i];
        }
        else
            return max_of_r(a, i-1);
    }
}

int main(void){
    int i,s;
    printf("i=");
    scanf("%d", &i);

    int a[i];
    for(s = 0;s < i;s++){
        printf("a[%d]=",s);
        scanf("%d", &a[s]);
    }

    printf("最大の点数は%d\n",max_of_r(a, i-1));
    return 0;
}