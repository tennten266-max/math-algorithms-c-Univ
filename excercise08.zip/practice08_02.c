#include <stdio.h>

double power3_r(int n){
    if(n==0){
        return 1;
    }
    else if(n % 2==0){
        return power3_r(n/2)*power3_r(n/2);
    }
    else{
        return 3 * power3_r(n-1);
    }

}

int main(void){
    int n;
    printf("n=");
    scanf("%d", &n);
    printf("%f\n", power3_r(n));
    return 0;
}