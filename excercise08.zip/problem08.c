#include <stdio.h>

int fn(int n);//呼び出し

int main(void){
    int n ;

    do{
    printf("Input non-negative integer n = ");
    scanf("%d",&n);
    } while (n < 0);

    printf("%d\n",fn(n));
}

int fn(int n){

    if(n <= 2) return 1;

    else return fn(n-2) + fn(n-1);

}//第n項のフィボナッチ数列