#include <stdio.h>
#include <math.h>

struct complex {
  double re;  /* 実部 */
  double im;  /* 虚部 */
};

void printC(struct complex a){
    if (a.re == 0 && a.im == 0)
        printf("nothing");
    else if (a.re == 0)                  //(a)
        printf("%+0.2f i\n", a.im);
    else if (a.im == 0)
        printf("%0.2f \n", a.re);
    else
        printf("%0.2f %+0.2f i\n", a.re, a.im);
}

struct complex addC(struct complex a, struct complex b){    //(b)
  struct complex c;
  c.re = a.re + b.re;
  c.im = a.im + b.im;
  return c;
}

struct complex multC(struct complex a, struct complex b){   //(c)
    struct complex c;
    c.re = a.re * b.re - a.im * b.im;
    c.im = a.re * b.im + a.im * b.re;
    return c;
}

struct complex conjC(struct complex a){     //(d)
    struct complex c;
    c.re = a.re ;
    c.im = -1 * a.im ;
    return c;
}

double absC(struct complex a){     //(e)
    double c;
    c = sqrt(a.re * a.re +  a.im * a.im );
    return c;
}

struct complex divC(struct complex a, struct complex b){   //(f)
    struct complex c;
    double a2 = absC(b);a2 *= a2;
    c.re = (a.re * b.re + a.im * b.im) / a2;
    c.im = (a.im * b.re - a.re * b.im) / a2;
    return c;
}

struct complex solve(double a, double b, double c, double D){
    struct complex ans;
    if (D < 0){
        ans.re = (-1 * b) / (2 * a);
        ans.im = sqrt(-1 * D) / (2 * a);//( - 1 * sqrt(D)) / (2 * a)もある
    }
    else{
        ans.re = ((-1 * b) + sqrt(D))/ (2 * a);//((-1 * b) - sqrt(D))/(2 * a)もある
        ans.im = 0;
    }
    return ans;    
}

int main(void) {
    struct complex ;
    double a, b, c, D;
    scanf("%lf", &a);
    if (a == 0)
        printf("a != 0\n");
    scanf("%lf", &b);
    scanf("%lf", &c);
    D = b * b -4 * a * c;
    
    printf("one of answer = ");
    if (D == 0){
        printf("%lf",(-1 * b / (2 * a)));
    }
    else{
        printC(solve(a, b, c, D));
    }
}