#include <stdio.h>
#include <math.h>

struct mat2 {
    double a, b, c, d;
};

double det(struct mat2 m){  //(a)
    return m.a * m.d - m.c * m.b;
}

struct complex {
  double re;  /* 実部 */
  double im;  /* 虚部 */
};

void printC(struct complex a){
    if (a.re == 0 && a.im == 0)
        printf("nothing\n");
    else if (a.re == 0)   
        printf("%+0.2f i\n", a.im);
    else if (a.im == 0)
        printf("%0.2f \n", a.re);
    else
        printf("%0.2f %+0.2f i\n", a.re, a.im);
}

struct complex solve(double a, double b, double c, double D){
    struct complex ans;
    if (D < 0){
        ans.re = (-1 * b) / (2 * a);
        ans.im = sqrt(-1 * D) / (2 * a);//( - 1 * sqrt(D)) / (2 * a)もある
    }
    else{
        ans.re = ((-1 * b) + sqrt(D))/ (2 * a);//((-1 * b) - sqrt(D))/(2 * a)もある
        ans.im = 0;
    }
    return ans;    
}

struct complex eig(struct mat2 m){  //(b)
    double T, D;
    T = m.a * m.d - m.b * m.c;
    D = (m.a + m.d) * (m.a + m.d) -1 * 4 * T;
    return solve(1, -1 * (m.a + m.d), T, D);
}

void scalarM(struct mat2 *pm, double p){     //(c)
    pm->a *= p;    
    pm->b *= p;    
    pm->c *= p;    
    pm->d *= p;
}

struct mat2 sumM(struct mat2 m1, struct mat2 m2){    //(d)
    struct mat2 m;
    m.a = m1.a + m2.a;
    m.b = m1.b + m2.b;
    m.c = m1.c + m2.c;
    m.d = m1.d + m2.d;
    return m;
}
struct mat2 multM(struct mat2 m1, struct mat2 m2){  //(e)
    struct mat2 m;
    m.a = m1.a * m2.a + m1.b * m2.c;
    m.b = m1.a * m2.b + m1.b * m2.d;
    m.c = m1.c * m2.a + m1.d * m2.c;
    m.d = m1.c * m2.b + m1.d * m2.d;
    return m;
}

int main(void){
    double a, b, c, d;
    struct mat2 m;
    printf("2*2行列m:");scanf("%lf %lf %lf %lf", &a, &b, &c, &d);
    m.a = a;
    m.b = b;
    m.c = c;
    m.d = d;

    printf("det(m) = %f\n",det(m));
    printf("固有値=");printC(eig(m));

    double p;
    printf("倍数p:");scanf("%lf", &p);
    scalarM(&m, p);    
    printf("%lf, %lf, %lf, %lf\n",m.a, m.b, m.c, m.d);
    
    struct mat2 m2;
    printf("2*2行列m2:");scanf("%lf %lf %lf %lf", &a, &b, &c, &d);
    m2.a = a;
    m2.b = b;
    m2.c = c;
    m2.d = d;

    printf("pm + m = %lf %lf %lf %lf\n",sumM(m, m2).a, sumM(m, m2).b, sumM(m, m2).c, sumM(m, m2).d);


    printf("pm * m = %lf %lf %lf %lf\n",multM(m, m2).a, multM(m, m2).b, multM(m, m2).c, multM(m, m2).d);

    return 0;
}

//時間がなく、読みずらいコードになってしまった。新しいprintの関数つくるべきだった