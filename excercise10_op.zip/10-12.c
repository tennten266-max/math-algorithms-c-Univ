#include <stdio.h> //cmd /c "a.exe < data.txt"
#include <string.h>

typedef struct student {
  int code;
  char name[100];
  int math;
  int eng;
} Student;

void read_student(Student *s) {
      scanf("%d", &s->code );
      scanf("%s", s->name);
      scanf("%d", &s->math);
      scanf("%d", &s->eng);
}

int search(Student a[], int num, const char *target){   //なぜ*
    int j,i;
    for (i = 0; i < num; i++){
        if(strcmp(a[i].name, target) == 0){
            j = i;
        }
    }
    return j;
}

void print_border(Student a[], int num, int s, int t){
    int i;
    for (i = 0; i <num; i++){
        if (a[i].math >= s && a[i].math <= t)
            printf("%03d\t", a[i].code);
            printf("%s\t", a[i].name);
            printf("%d\t", a[i].math);
            printf("%d\n", a[i].eng);
    }
}

void adjust(Student *a, int num, int s, int t){
    int i;
    for (i = 0; i <num; i++){
        if (a[i].math >= s && a[i].math <= t)
            a[i].math = t;
    }
}

int main(void) {
   int num, i;
   /* 人数を指定 */
   scanf("%d", &num);
   /* num個のStudent型構造体を宣言 */
   Student a[num];
   /* num個のStudent型構造体に情報を入力 */
   for (i = 0; i < num; i++) {
      read_student(&a[i]);
   }
   /* num個のStudent型構造体の情報を表示 */
   for (i = 0; i < num; i++) {
      printf("%03d\t", a[i].code);
      printf("%s\t", a[i].name);
      printf("%d\t", a[i].math);
      printf("%d\n", a[i].eng);
   }

    int s = 50,t = 55;
    print_border(a, num, s, t);
    adjust(a, num, s, t);
    for (i = 0; i < num; i++) {
       printf("%03d\t", a[i].code);
       printf("%s\t", a[i].name);
       printf("%d\t", a[i].math);
       printf("%d\n", a[i].eng);
    }

}