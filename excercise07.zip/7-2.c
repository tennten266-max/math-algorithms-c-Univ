#include <stdio.h>

int divisible(int n, int i) { // (a)
    if (i == 0) {
        return 0;
    }
    if (n % i == 0) {
        return 1; 
    } else {
        return 0; 
    }
}

int sod(int n, int k) { // (b)
    int sum_of_divisors = 0; 
    int i; 

    if (n <= 0) {
        return 0;
    }

    for (i = 1; i <= k; i++) {
        if (divisible(n, i) == 1) {
            sum_of_divisors += i; 
        }
    }

    return sum_of_divisors; 
}


int main(void) { // (c)
    int m, l; // (m: 数, l: 上限)

    printf("非負整数mとlを入力: ");
    scanf("%d %d", &m, &l);

    printf("sod(%d, %d) の結果は %d です。\n", m, l, sod(m, l));

    return 0;
}