#include <stdio.h>
int sum(int n);

int main(void){
    int x;
    printf("x=");scanf("%d",&x);
    printf("sum=%d\n",sum(x));
    return 0;
}



int sum(int n){
    int sum, i;
    sum = 0;
    for(i = 0;i<=n; i++)
    {
        sum += i;
    }
    return sum;
}