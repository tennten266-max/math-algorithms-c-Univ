#include <stdio.h>

int divisible(int n, int i) {
    if (i == 0) {
        return 0;
    }
    if (n % i == 0) {
        return 1;
    } else {
        return 0;
    }
}

int sod(int n, int k) {
    int sum_of_divisors = 0;
    int i;

    if (n <= 0) {
        return 0;
    }

    for (i = 1; i <= k; i++) {
        if (divisible(n, i) == 1) {
            sum_of_divisors += i;
        }
    }

    return sum_of_divisors;
}

int find_largest_perfect_number(int max_limit) {
    int current_num;
    int largest_perfect = 0; // 0は完全数とする 

    for (current_num = 1; current_num <= max_limit; current_num++) {
        if (current_num == 0) {
             largest_perfect = 0;
             continue; 
        }

        int sum_proper_divisors = sod(current_num, current_num - 1);

        // 完全数かどうかを判定する 
        if (sum_proper_divisors == current_num) {
            largest_perfect = current_num; // より大きな完全数が見つかった
        }
    }

    return largest_perfect;
}


int main(void) {
    int n; 

    printf("完全数を探索する上限: ");scanf("%d", &n);

    if (n >= 0) {
        int result = find_largest_perfect_number(n);

        if (result != 0) {
            printf("%d以下の最大の完全数は %d です\n", n, result);
        } else if (n >= 0) {
             printf("%d以下の最大の完全数は 0 です\n", n);
        } else {
             printf("指定された範囲内に完全数はありません\n");
        }
    } else {
        printf("非負整数を入力してください\n");
    }
    

    return 0;
}