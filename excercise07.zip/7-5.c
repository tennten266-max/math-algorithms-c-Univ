#include <stdio.h>

int is_prime(int n) { // (a)
    int i; // ループ用
    if (n <= 1) {
        return 0;
    }

    if (n == 2) {
        return 1;
    }

    for (i = 2; i < n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }

    return 1; // どの数でも割り切れなければ素数
}

int next_prime(int n) { // (b)
    int next_num = n + 1; // nの次の整数から探す

    // 無限ループで探索、素数はあるはず
    while (is_prime(next_num) == 0) {
        next_num++; 
    }
    return next_num;
}

int main(void) {
    int x; 
    printf("正の整数xを入力: ");scanf("%d", &x);

    if (x > 0) {
        if (is_prime(x) == 1) {
            printf("%d は素数\n", x);
        } else {
            printf("%d は素数ではありません\n", x);
        }

        int next = next_prime(x);
        printf("%d より大きな最小の素数は %d です\n", x, next);
    } else {
        printf("正の整数を入力してください\n");
    }

    return 0;
}