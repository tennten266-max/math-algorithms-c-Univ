#include <stdio.h>

int count(int a[], int n, int p) {
    int i;           // ループ用
    int pass_count = 0; // p点以上の人数を格納する変数

    for (i = 0; i < n; i++) {
        if (a[i] >= p) {
            pass_count++; 
        }
    }

    return pass_count; 
}

int main(void) {
    int num_students = 10; // 学生の人数10人
    int threshold = 80;    // 基準点80点
    int scores[10]; // 10人分の点数を格納する配列
    int i;          // ループ用

    printf("%d人の試験の点数を入力\n", num_students);

    for (i = 0; i < num_students; i++) {
        printf("%d人目: ", i + 1);scanf("%d", &scores[i]);
    }

    printf("%d点以上の人数は %d 人です\n", threshold, count(scores, num_students, threshold));

    return 0;
}