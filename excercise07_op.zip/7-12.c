#include<stdio.h>
#include<math.h>

double vecmult(double a[], double b[], int n){//(a)
    int i;
    double c = 0;
    for(i = 0; i < n; i++){
        c += a[i] * b[i];
    }

    return c;//内積
}

double norm(double a[], int n){//(b)
    double d = 0;
    d = sqrt(vecmult(a, a, n));

    return d;
}

void vecsum(double a[], double b[], int n){//(c)
    int i;
    double c[n];
    for(i = 0; i < n; i++){
        c[i] = a[i] + b[i];
    }

    for(i = 0; i < n; i++){
        printf("和c[%d]=%f\n",i,c[i]);
    }
}

int main(void){
    int n, i;
    n=2;
    double a[n], b[n];

    for(i = 0; i < n; i++){
        printf("a[%d]=",i);scanf("%lf", &a[i]);
    }
    for(i = 0; i < n; i++){
        printf("b[%d]=",i);scanf("%lf", &b[i]);
    }

    printf("内積は%f\n",vecmult(a, b, n));
    printf("norm=%f\n",norm(a, n));
    vecsum(a, b, n);

    return 0;
}