#include<stdio.h>
int perm(int n, int m){
    if(n < 0 || m < 0){
        printf("illegal date\n");
        return -1;
    }else if(n < m){
        printf("inconsistent date\n");
        return -1;
    }else{
        int i, np = 1;
        for(i = n - m + 1; i <= n; i++){
            np *= i;
        }
        return np;
    }
}

int main(void){
    int n,m;
    printf("n=");scanf("%d",&n);
    printf("m=");scanf("%d",&m);
    
    printf("perm=%d",perm(n,m));
    return 0;
}