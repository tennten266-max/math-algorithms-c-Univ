#include<stdio.h>
int rank(int a[], int j, int n){
    int i,t,count;        //iはループ用
    count = 0;
    for(i = 0; i < n; i++){
        if(a[j]<= a[i]){
            count++;
        }
    }

    return count;
}

int main(void){
    int i,n,j;
    n=10;
    int a[n];
    for(i = 0; i < n; i++){
        printf("a[%d]=",i);scanf("%d",&a[i]);
    }
    for(j = 0; j < n; j++){
        printf("%d人目の順位は%d位\n",j ,rank(a, j ,n));
    }

    return 0;
}