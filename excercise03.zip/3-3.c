#include<stdio.h>

int main(void){

    int a, b,c;
    double D;
    printf("a(≠0)=");scanf("%d",&a);
    printf("b=");scanf("%d",&b);
    printf("c=");scanf("%d",&c);

    D = b*b - 4 * a * c;
    if(D >= 0)
    {
        if(D == 0)
        {
            printf("ax^2+bx+c=0の2次方程式の解の個数は1個");
        }
        else
        {
            printf("ax^2+bx+c=0の2次方程式の解の個数は2個");
        }
    }
    else
    {
        printf("ax^2+bx+c=0の2次方程式の解の個数は0個");
    }
}