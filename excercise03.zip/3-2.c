/*
    float型は有効数字7桁であり、aとdの計算をすると、有効数字7桁におさまらない数が出るため
    実際s = s + aの直後s = s + dを行えばfloat型でも正しく計算できる
 */
 #include<stdio.h>
int main(void){
    double a, b, c, d, s;

    a = 100001.0;
    b = 0.123456;
    c = 0.111111;
    d = -100000.0;

    s = 0.0;
    s = s + a;
    s = s + b;
    s = s + c;
    s = s + d;

    printf("%f\n", s);
}