#include<stdio.h>

int main(void){

    int x;
    printf("x=");scanf("%d",&x);
    printf("%d番目の英小文字は",x);
    putchar(x + 96);
    
}