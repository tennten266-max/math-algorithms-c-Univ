#include<stdio.h>
int main(void)
{
    int n;
    long sum;
    sum = 1;

    scanf("%d",&n);
    int i;
    for(i = 0;i  n;i++)
    {
        sum *= 2;
    }
    printf("%ld\n",sum);
}