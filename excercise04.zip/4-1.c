#include<stdio.h>
int main(void)
{
    int n;
    unsigned long long int sum;
    sum = 1;

    scanf("%d",&n);
    int i;
    for(i = 1;i <= n;i++)
    {
        sum *= i;
    }
    printf("%llu\n",sum);

}