/*
    コンピュータは数字や文字を2進数で処理するが、0.00001は2進数だときれいに表すことができない。
    そのため誤差が生じる

    一方2^-20は2進数できれいにあらわせるため、double型で(扱う桁を増やして)計算するとうまくいく。
*/
#include<stdio.h>
#include<math.h>
int main(void)
{
    float x;
    long i;

    x = 0.0;
    for(i = 0;i<100000;i++){
        x = x + 0.00001;
    }
    printf("i = %d,x = %10.7f, |error|=%10.7f\n",i,x,fabs(1.0-x));

    x = 1/1048576;
    for(i = 0;i<1048576;i++){
        x = x + (double)1/1048576;
    }
    printf("i = %d,x = %10.7f, |error|=%10.7f\n",i,x,fabs(1.0-x));
}