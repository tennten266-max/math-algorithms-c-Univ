#include<stdio.h>//scanfに\nはいれない
int main(void)
{
    int a[5],b[5];
    int n,i;

    printf("整数nは");scanf("%d",&n); 
    for(i=0;i<5;i++)
    {
        printf("a[%d]=",i);scanf("%d",&a[i]);
    }

    for(i=0;i<5;i++)
    {
        b[i] = n * a[i];
    }

    printf("結果は\n");
    for(i=0;i<5;i++)
    {
        printf("b[%d]=%d\n",i,b[i]);
    }
}